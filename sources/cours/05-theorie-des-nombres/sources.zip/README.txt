Chapitre 5 — Théorie des nombres — sources LaTeX (site COMIMa).

Compilation :
  latexmk -pdf cours.tex
(ou pdflatex cours.tex, deux passes)

Paquets requis : TeX Live avec texlive-latex-extra (mdframed, needspace,
etoolbox), texlive-lang-french, texlive-pictures.

Fichiers :
  cours.tex            — document maître du chapitre
  preamble.tex         — préambule commun COMIMa
  preamble-cours.tex   — mise en page des chapitres (A5, encadrés…)
  <exercice>/enonce.tex, solution.tex — exercices inclus dans le chapitre

Édition publique : les solutions des exercices ne sont pas incluses (réservées aux encadreurs).
